name = "rlcard"

from rlcard.envs import make
